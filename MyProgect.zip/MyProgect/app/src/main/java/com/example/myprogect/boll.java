package com.example.myprogect;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class boll extends Activity {

    protected Button b1;
    protected Button b2;
    protected SurfaceView boa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.boll);
        b1 = (Button) findViewById(R.id.back);
        b2 = (Button) findViewById(R.id.forw);

        View.OnClickListener oclBtn = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(boll.this, board.class);
                startActivity(intent);

            }
        };
        b1.setOnClickListener(oclBtn);

        View.OnClickListener oclB = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(boll.this, MainActivity.class);
                startActivity(intent);

            }
        };
        b2.setOnClickListener(oclB);
        setContentView(new MyDrawBoll(this));
    }
}

