package com.example.myprogect;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;

public class board extends Activity {

    protected Button b1;
    protected Button b2;
    protected SurfaceView boa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.board);
        b1 = (Button) findViewById(R.id.back);
        b2 = (Button) findViewById(R.id.forw);

        View.OnClickListener oclBtn = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(board.this, MainActivity.class);
                startActivity(intent);

            }
        };
        b1.setOnClickListener(oclBtn);

        View.OnClickListener oclB = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(board.this, boll.class);
                startActivity(intent);

            }
        };
        b2.setOnClickListener(oclB);
        setContentView(new MyDrawBoa(this));
    }

}

/*


btnExit = (Button) findViewById(R.id.button);
        b1 = (Button) findViewById(R.id.radioButton1);
        b2 = (Button) findViewById(R.id.radioButton2);
        b3 = (Button) findViewById(R.id.radioButton3);
        t = (TextView) findViewById(R.id.textView);
        res = (TextView) findViewById(R.id.textView2);


        res.setText(res.getText()+" Стартуем :)");
        //Game myGame=new Game();
        //myGame.main();

        View.OnClickListener oclBtn = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                res.setText("Exit button click");
                Log.v("Debug","Exit button click");
                System.exit(0);
            }
        };
        btnExit.setOnClickListener(oclBtn);

        View.OnClickListener oclB = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.radioButton1:
                        Toast.makeText(getApplicationContext(), "Первый ответ",
                                Toast.LENGTH_SHORT).show();
                        myGame.goGame(1);
                        break;
                    case R.id.radioButton2:
                        Toast.makeText(getApplicationContext(), "Второй ответ",
                                Toast.LENGTH_SHORT).show();
                        myGame.goGame(2);
                        break;
                    case R.id.radioButton3:
                        Toast.makeText(getApplicationContext(), "Третий ответ",
                                Toast.LENGTH_SHORT).show();
                        myGame.goGame(3);
                        break;
                    default:
                        break;
                }
            }
        };

        b1.setOnClickListener(oclB);
        b2.setOnClickListener(oclB);
        b3.setOnClickListener(oclB);
*/