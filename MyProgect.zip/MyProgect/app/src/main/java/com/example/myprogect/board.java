package com.example.myprogect;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class board extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
        int W=dm.widthPixels;
        int H=dm.heightPixels;

        if ((0.8*W)/(0.94*H) < MainActivity.sizXm/MainActivity.sizYm) {
            Toast.makeText(getApplicationContext(), "x="+W+" y="+H+" x0="+MainActivity.sizXm+" y0="+MainActivity.sizYm, Toast.LENGTH_SHORT).show();
            android.view.ViewGroup.LayoutParams lp = new android.view.ViewGroup.LayoutParams(W, (int)(0.8/0.94*W*MainActivity.sizYm/MainActivity.sizXm));
            setContentView(new MyDrawBoa(this), lp);
        }
        else setContentView(new MyDrawBoa(this));
    }

    public void GotoMainActivity(){
        finish();
    }
}
