package com.example.myprogect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Set;
import java.util.function.DoubleToIntFunction;


public class MainActivity extends AppCompatActivity {

    public static MainActivity m;
    protected Button b1, b2;
    protected Spinner sType,sBoard;
    public EditText powHit, powSlow, diam, timeInter, ang, X1,Y1, X2,Y2;
    protected TextView myText;

    //глобальные параметры для расчета движения
    public static double Hit=6; //начальная скорость шара в м/с
    public static double Slow=3; //ускорение замедления за счет трения м/с*2
    public static double Inter=5; //интервал рачета в миллисекундах
    public static double Angel=25; //угол/направление удара по шару в градусах
    public static double shR=0; //расстояние от центра шара до точки удара в процентах от диаметра
    public static double shAng=0; //угол отклонения точки удара по шару от вертикальной линии в градусах
    public static double shDiam=68; //диаметр шара, мм
    static public double sizXm = 0, sizYm = 0; //размеры стола в миллиметрах
    static public double x1 = 0.75, y1 = 0.75; //начальные координаты шара1
    static public double x2 = 0.5, y2 = 0.5; //начальные координаты шара2
    public static String tip, siz; //тип стола и размер стола
    String[] str;

    @Override
    public void onResume(){
        super.onResume();
        SetParam();
    }
    public void SetParam(){

        powHit.setText(Integer.toString((int) Hit));
        powSlow.setText(Integer.toString((int) Slow));
        diam.setText(Integer.toString((int) shDiam));
        timeInter.setText(Integer.toString((int) Inter));
        ang.setText(Integer.toString( (int) Angel));
        X1.setText(String.format(Locale.US,"%.5f", x1));
        Y1.setText(String.format(Locale.US,"%.5f", y1));
        X2.setText(String.format(Locale.US,"%.5f", x2));
        Y2.setText(String.format(Locale.US,"%.5f", y2));
        myText.setText("От центра шара до точки удара, %: " +String.format("%.1f",shR)+'\n'+
                "Угол отклонения точки удара, градусы: "+String.format("%.1f",shAng));
    }

    public void LoadParam() {
        Hit = Integer.parseInt(powHit.getText().toString());
        Slow = Integer.parseInt(powSlow.getText().toString());
        shDiam = Integer.parseInt(diam.getText().toString());
        Inter = Integer.parseInt(timeInter.getText().toString());
        Angel = Integer.parseInt(ang.getText().toString());
        x1 = Double.parseDouble(X1.getText().toString());
        y1 = Double.parseDouble(Y1.getText().toString());
        x2 = Double.parseDouble(X2.getText().toString());
        y2 = Double.parseDouble(Y2.getText().toString());
        CheckParam();
    }

        public static void CheckParam(){
        if(Hit > 13) Hit = 13;
        if(Hit < 1) Hit = 1;
        if(Slow > 15) Slow = 15;
        if(Slow < 1) Slow = 1;
        if(Inter > 13) Inter = 13;
        if(Inter < 1) Inter = 1;
        shDiam=Math.abs(shDiam)%80; //диаметр шара от 0 до 80 мм

            if(x1 < shDiam/2.0/1000.0) x1 = shDiam/2.0/1000.0;
            if(y1 < shDiam/2.0/1000.0) y1 = shDiam/2.0/1000.0;
            if(x1 > sizXm-shDiam/2.0/1000.0) x1 = sizXm-shDiam/2.0/1000.0;
            if(y1 > sizYm-shDiam/2.0/1000.0) y1 = sizYm-shDiam/2.0/1000.0;

            if(x2 < shDiam/2.0/1000.0) x2 = shDiam/2.0/1000.0;
            if(y2 < shDiam/2.0/1000.0) y2 = shDiam/2.0/1000.0;
            if(x2 > sizXm-shDiam/2.0/1000.0) x2 = sizXm-shDiam/2.0/1000.0;
            if(y2 > sizYm-shDiam/2.0/1000.0) y2 = sizYm-shDiam/2.0/1000.0;

        if(Math.abs(Angel) >= 360) Angel = Angel % 360;
        if(Angel < 0) Angel += 360;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m=this;
        b1 = (Button) findViewById(R.id.back);
        b2 = (Button) findViewById(R.id.forw);
        sType = (Spinner) findViewById(R.id.type);
        sBoard = (Spinner) findViewById(R.id.BoardSize);
        myText = (TextView) findViewById(R.id.myText);
        powHit = (EditText) findViewById(R.id.powerHit);
        powSlow = (EditText) findViewById(R.id.powerSlow);
        diam = (EditText) findViewById(R.id.diam);
        timeInter = (EditText) findViewById(R.id.timeInterval);
        ang = (EditText) findViewById(R.id.angle);
        X1 = (EditText) findViewById(R.id.x1);
        Y1 = (EditText) findViewById(R.id.y1);
        X2 = (EditText) findViewById(R.id.x2);
        Y2 = (EditText) findViewById(R.id.y2);
        //заполняем параметны на экране из переменных в памяти
        SetParam();
        //заполняем спиннер с размерами столов и рассчитываем значения переменных в памяти
        tip = sType.getSelectedItem().toString();
        bran(sType.getSelectedItem().toString());
        Split();

        //назначаем обработчики нажатий на кнопки
        View.OnClickListener oclBtn = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        };
        b1.setOnClickListener(oclBtn);

        View.OnClickListener oclB = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoadParam(); //загружаем значения из экранных элементов в глобальные переменные
                Split();
                Intent intent = new Intent(MainActivity.this,board.class);
                startActivity(intent);
            }
        };
        b2.setOnClickListener(oclB);

        sType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {

                final Object item = adapterView.getItemAtPosition(position);
                if (item != null) { bran(item.toString()); }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // TODO Auto-generated method stub

            }
        });

    }

    protected void bran(String tip){
        int mID=R.layout.support_simple_spinner_dropdown_item;
        if (tip.equals("Русская пирамида")){
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.RussianSize, mID);
            adapter.setDropDownViewResource(mID);
            sBoard.setAdapter(adapter);
            Split();
        }
        if (tip.equals("Американский пул")){
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.PulSize, mID);
            adapter.setDropDownViewResource(mID);
            sBoard.setAdapter(adapter);
            Split();
        }
    }

    public void Split(){
        siz = sBoard.getSelectedItem().toString();
        str = siz.split(" ");
        sizYm = Double.parseDouble(str[0]);
        sizXm = Double.parseDouble(str[2]);
        x1=sizXm/2;
        y1=sizYm*0.75;
        x2=sizXm/2;
        y2=sizYm*0.25;
    }

}
