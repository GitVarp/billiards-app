package com.example.myprogect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    protected Button b1, b2;
    protected Spinner sType,sBoard;
    protected EditText powHit, powSlow, timeLim, timeInter, ang;
    public static int Hit, Slow, Lim, Inter, Angel;
    public static String tip, siz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button) findViewById(R.id.back);
        b2 = (Button) findViewById(R.id.forw);

        sType = (Spinner) findViewById(R.id.type);
        sBoard = (Spinner) findViewById(R.id.BoardSize);

        tip = sType.getSelectedItem().toString();
        siz = sBoard.getSelectedItem().toString();

        powHit = (EditText) findViewById(R.id.powerHit);
        powSlow = (EditText) findViewById(R.id.powerSlow);
        timeLim = (EditText) findViewById(R.id.timeLimit);
        timeInter = (EditText) findViewById(R.id.timeInterval);
        ang = (EditText) findViewById(R.id.angle);

        Hit = Integer.parseInt(powHit.getText().toString());
        Slow = Integer.parseInt(powSlow.getText().toString());
        Lim = Integer.parseInt(timeLim.getText().toString());
        Inter = Integer.parseInt(timeInter.getText().toString());
        Angel = Integer.parseInt(ang.getText().toString());
//Integer.parseInt


        View.OnClickListener oclBtn = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Hit = Integer.parseInt(powHit.getText().toString());
                Slow = Integer.parseInt(powSlow.getText().toString());
                Lim = Integer.parseInt(timeLim.getText().toString());
                Inter = Integer.parseInt(timeInter.getText().toString());
                Intent intent = new Intent(MainActivity.this,boll.class);
                startActivity(intent);

            }
        };
        b1.setOnClickListener(oclBtn);

        View.OnClickListener oclB = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Hit = Integer.parseInt(powHit.getText().toString());
                Slow = Integer.parseInt(powSlow.getText().toString());
                Lim = Integer.parseInt(timeLim.getText().toString());
                Inter = Integer.parseInt(timeInter.getText().toString());
                Intent intent = new Intent(MainActivity.this,board.class);
                startActivity(intent);

            }
        };
        b2.setOnClickListener(oclB);



        sType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override 
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {

                Object item = adapterView.getItemAtPosition(position);
                if (item != null) {
                    /*Toast.makeText(MainActivity.this, item.toString(),
                            Toast.LENGTH_SHORT).show();*/
                    bran(item.toString());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // TODO Auto-generated method stub

            }
        });
    }

    protected void bran(String tip){
        int mID=R.layout.support_simple_spinner_dropdown_item;
        if (tip.equals("Русская пирамида")){
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.RussianSize, mID);
            adapter.setDropDownViewResource(mID);
            sBoard.setAdapter(adapter);

        }
        if (tip.equals("Американский пул")){
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.PulSize, mID);
            adapter.setDropDownViewResource(mID);
            sBoard.setAdapter(adapter);

        }
    }

}



/*  Intent intent = new Intent(MainActivity.this,board.class);
        startActivity(intent); */