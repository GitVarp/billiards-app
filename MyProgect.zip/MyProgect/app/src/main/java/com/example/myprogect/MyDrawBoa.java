package com.example.myprogect;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.HashMap;

class Pos {
double X;
    double Y;
    double F;
    double V0;
}

public class MyDrawBoa extends View{
    MainActivity main = new MainActivity();
    ArrayList <Pos> line = new ArrayList();
    int tm = main.Lim/main.Inter, timeInterval = main.Inter;
    int touchX = -500, touchY=-500;


    public MyDrawBoa(Context context) {
        super(context);
        Pos p = new Pos();
        p.X=touchX;
        p.Y=touchY;
        line.add(p);
    }

    @Override
    protected void onDraw(Canvas canvas) {


        super.onDraw(canvas);
        Paint paint = new Paint();
        // Выбираем кисть
        paint.setStyle(Paint.Style.FILL);
        // Белый цвет кисти
        paint.setColor(Color.BLACK);
        // Закрашиваем холст
        canvas.drawPaint(paint);
        // Включаем антиальясинг
        paint.setAntiAlias(true);

        // Зеленый прямоугольник
        paint.setColor(Color.GREEN);
        canvas.drawRect(20, 20, getWidth()-20,getHeight()-20, paint);

        //Лунки
        paint.setColor(Color.GRAY);

        for (int i = 0;i<3;i++){
            canvas.drawCircle(20, 20+((getHeight()/2-20)*i), 20, paint);
            canvas.drawCircle(getWidth()-20, 20+((getHeight()/2-20)*i), 20, paint);
        }

        paint.setColor(Color.WHITE);
        canvas.drawCircle(touchX, touchY, 15, paint);

        for(int i=0; i<line.size()-2; i++)
        {canvas.drawLine((int) line.get(i).X, (int) line.get(i).Y, (int) line.get(i+1).X, (int) line.get(i+1).Y, paint);
        }

        paint.setColor(Color.RED);
        for(int i=0; i<line.size()-1; i++)
        {canvas.drawCircle((int) line.get(i).X, (int) line.get(i).Y, 2, paint);
        }
        canvas.drawCircle((int) line.get(line.size()-1).X, (int) line.get(line.size()-1).Y, 15, paint);

    }

    public boolean onTouchEvent(MotionEvent event) {
        boolean flag = false;
        System.err.println("Start onTouch!!!!");
        int eventAction = event.getAction();
        if (eventAction == MotionEvent.ACTION_DOWN)  {

            touchX = (int) event.getX();
            touchY= (int) event.getY();
            line.removeAll(line);
            Pos p= new Pos();
            p.F=main.Angel;
            p.V0=main.Hit;
            p.X=touchX;
            p.Y=touchY;
            line.add(p);
            double dS;
            double a=0;


            while(line.get(line.size()-1).V0>0)
            {
                p= new Pos();
                p.X=line.get(line.size()-1).X;
                p.Y=line.get(line.size()-1).Y;
                p.F=line.get(line.size()-1).F;
                p.V0=line.get(line.size()-1).V0;

                dS= p.V0*timeInterval/1000.0;
                p.V0=p.V0-main.Slow/1000.0*timeInterval;
                if (p.V0<0) p.V0=0;

                a=p.F;

                double dX = dS/Math.sin(a*Math.PI/180);
                double dY = dS/Math.cos(a*Math.PI/180);

                p.X= p.X+dX;
                p.Y= p.Y-dY;


                if (p.X< 21+15){
                    if (a>270) {p.F=p.F+90-360;} else {if (a<270){p.F=p.F-90;} else {p.F=90;}}
                    p.X= 21+15;
                }

                if (p.Y< 21+15){
                    if (a<90) {p.F=p.F+90;} else {if (a>270){p.F=p.F-90;} else {p.F=180;}}
                    p.Y=21+15;
                }

                if (p.X> getWidth()-21-15){
                    if (a<90) {p.F=360+(p.F-90);} else {if (a>90){p.F=p.F+90;} else {p.F=270;}};
                    p.X= getWidth()-21-15;
                }

                if (p.Y> getHeight()-21-15){
                    if (a>180) {p.F=p.F+90;} else {if (a<180){p.F=p.F-90;} else {p.F=0;}};
                    p.Y= getHeight()-21-15;
                    }

                line.add(p);

            }
            //for (Pos pp : line) {System.err.println(pp.X+" "+ pp.Y +" "+pp.F+" "+pp.V0+" ");};
            invalidate ();
        }
        return true;
    }


}
/*
// Полупрозрачный синий круг радиусом 100 пикселей в центре экрана
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, 100, paint);

//  Выбор цвета
        paint.setColor(Color.argb(127,0,0,255));

// Текст
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(30);
        canvas.drawText("Samsung IT school", 50, 100, paint);

// текст под углом
        float rotate_center_x = 200; //центр поворота по оси X
        float rotate_center_y = 200; // центр поворота по оси Y
        float rotate_angle = 45; //угол поворота

// поворачиваем холст
        canvas.rotate(-rotate_angle, rotate_center_x, rotate_center_y);


        paint.setColor(Color.BLACK);
        paint.setTextSize(40);

        canvas.drawText("Samsung IT school",0,450,paint);

// возвращаем холст на прежний угол
        canvas.rotate(rotate_angle, rotate_center_x, rotate_center_y);
* */