package com.example.myprogect;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

class Pos {
    double X;
    double Y;
    double F;
    double V0;
}

public class MyDrawBoa extends View{
    MainActivity main = MainActivity.m;
    Context c=null;
    ArrayList <Pos> line1= new ArrayList(), line2 = new ArrayList();
    double coeff;

    public MyDrawBoa(Context context) {
        super(context);
        coeff=0;
        Pos p = new Pos();
        line1.add(p);
        c=context;
    }


    @SuppressLint("DrawAllocation")
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Paint paint = new Paint();
        // Выбираем кисть
        paint.setStyle(Paint.Style.FILL);
        // Черный цвет кисти
        paint.setColor(Color.BLACK);
        // Закрашиваем холст
        canvas.drawPaint(paint);
        // Включаем антиальясинг
        paint.setAntiAlias(true);

        //расчет траектории
        coeff=getHeight()*0.94/main.sizYm;
        Calculate();

        // края стола
        paint.setColor(Color.rgb(128,128,0));
        RectF rect = new RectF( (float) (getWidth()*0.10), 0, (float) (main.sizXm*coeff+getWidth()*0.20), (float) (getHeight()));
        canvas.drawRoundRect(rect, 30, 30, paint);

        paint.setColor(Color.rgb(25,150,25));
        rect.left=(float) (getWidth()*0.125);
        rect.top=(float) (getHeight()*0.015);
        rect.right=(float) (main.sizXm*coeff+getWidth()*0.175);
        rect.bottom=(float) (0.985*getHeight());
        canvas.drawRoundRect(rect, 25, 25, paint);

        // Зеленый прямоугольник, игровое поле
        paint.setColor(Color.GREEN);
        canvas.drawRect((float) (getWidth()*0.15), (float) (getHeight()*0.03), (float) (main.sizXm*coeff+getWidth()*0.15), (float) (0.97*getHeight()), paint);
        //выбираем кисть
        paint.setStyle(Paint.Style.STROKE);
        //контрольный прямоугольник
        paint.setColor(Color.WHITE);
        canvas.drawRect((float) (getWidth()*0.15)-2, (float) (getHeight()*0.03)-2, (float) (getWidth()*0.97)+2, (float) (0.97*getHeight()+2), paint);

        //окантовка кнопок
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.DKGRAY);
        paint.setStrokeWidth(0);
        canvas.drawRect(0, 0, (float) (getWidth() * 0.10), (float) (getHeight() * 0.33), paint);
        canvas.drawRect( 0, (float) (getHeight() * 0.33), (float) (getWidth() * 0.10), (float) (getHeight() * 0.66), paint);
        canvas.drawRect(0, (float) (getHeight() * 0.66), (float) (getWidth() * 0.10), (float) (getHeight()), paint);

        //кнопки
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(175,175,175));
        canvas.drawRect((float) (getWidth() * 0.01), (float) (getHeight() * 0.01), (float) (getWidth() * 0.09), (float) (getHeight() * 0.32), paint);
        canvas.drawRect( (float) (getWidth() * 0.01), (float) (getHeight() * 0.34), (float) (getWidth() * 0.09), (float) (getHeight() * 0.65), paint);
        canvas.drawRect((float) (getWidth() * 0.01), (float) (getHeight() * 0.67), (float) (getWidth() * 0.09), (float) (getHeight()*0.82), paint);
        canvas.drawRect((float) (getWidth() * 0.01), (float) (getHeight() * 0.84), (float) (getWidth() * 0.09), (float) (getHeight()*0.99), paint);

        //текст на кнопках
        canvas.save();
        canvas.rotate(90);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(0);
        paint.setTextSize((float) (getWidth() * 0.05));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("Назад", (float) (getHeight()*0.33/2), (float) (0-getWidth() * 0.05- ((paint.descent() + paint.ascent()) / 2)),  paint);
        canvas.drawText("Настройки удара", (float) (getHeight()/2.0), (float) (0-getWidth() * 0.05- ((paint.descent() + paint.ascent()) / 2)),  paint);
        canvas.drawText("+", (float) (getHeight()*9.0/12.0), (float) (0-getWidth() * 0.05- ((paint.descent() + paint.ascent()) / 2)),  paint);
        canvas.drawText("-", (float) (getHeight()*11.0/12.0), (float) (0-getWidth() * 0.05- ((paint.descent() + paint.ascent()) / 2)),  paint);

        canvas.restore();

        canvas.drawText(Integer.toString((int) MainActivity.Angel), (float) (getWidth()*0.05), (float) (getHeight()*14.0/20.0 - ((paint.descent() + paint.ascent()) / 2)),  paint);

        //Лунки
        paint.setStyle(Paint.Style.FILL);

        paint.setColor(Color.rgb(30,80,30));

        for (int i = 0;i<3;i++){
            canvas.drawCircle((float) (getWidth()*0.15), (float) (getHeight()*0.03+getHeight()*0.47*i), (float) (coeff*0.06), paint);
            canvas.drawCircle((float) (main.sizXm*coeff+getWidth()*0.15), (float) (getHeight()*0.03+getHeight()*0.47*i), (float) (coeff*0.06), paint);
        }

        //рисуем шарик белый в начале траектории
        paint.setColor(Color.WHITE);
        paint.setStrokeWidth((int)(getWidth()/300));
        canvas.drawCircle( (int) line1.get(0).X, (int) line1.get(0).Y, (float) (main.shDiam*coeff/1000.0/2), paint);

        //рисуем черный шарик  в начале траектории
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth((int)(getWidth()/300));
        canvas.drawCircle( (int) line2.get(0).X, (int) line2.get(0).Y, (float) (main.shDiam*coeff/1000.0/2), paint);

        //рисуем траекторию 1
        paint.setColor(Color.WHITE);
        for(int i=0; i<line1.size()-2; i++)
        {canvas.drawLine((int) line1.get(i).X, (int) line1.get(i).Y, (int) line1.get(i+1).X, (int) line1.get(i+1).Y, paint);
        }
        paint.setColor(Color.RED);
        for(int i=0; i<line1.size()-1; i++)
        {canvas.drawCircle((int) line1.get(i).X, (int) line1.get(i).Y, (int)(getWidth()/300), paint);}

        //рисуем траекторию 2
        paint.setColor(Color.WHITE);
        for(int i=0; i<line2.size()-2; i++)
        {canvas.drawLine((int) line2.get(i).X, (int) line2.get(i).Y, (int) line2.get(i+1).X, (int) line2.get(i+1).Y, paint);
        }
        paint.setColor(Color.BLUE);
        for(int i=0; i<line2.size()-1; i++)
        {canvas.drawCircle((int) line2.get(i).X, (int) line2.get(i).Y, (int)(getWidth()/300), paint);}

        //рисуем красный и синий шарик в конце траектории
        paint.setColor(Color.RED);
        if (line1.size()>1) canvas.drawCircle((int) line1.get(line1.size()-1).X, (int) line1.get(line1.size()-1).Y, (float) (main.shDiam*coeff/1000.0/2), paint);
        paint.setColor(Color.BLUE);
        if (line2.size()>1) canvas.drawCircle((int) line2.get(line2.size()-1).X, (int) line2.get(line2.size()-1).Y, (float) (main.shDiam*coeff/1000.0/2), paint);
    }


    //обработчтк нажатий
    public boolean onTouchEvent(MotionEvent event) {
        int eventAction = event.getAction();
        if (eventAction == MotionEvent.ACTION_DOWN) {
            //System.err.println("Start onTouch!!!!");
            int touchX = (int) event.getX();
            int touchY = (int) event.getY();
            //обрабатываем нажатия на кнопки
            if (touchX < getWidth() * 0.1) {
                if (touchY < getHeight() * 0.33) {
                    board b = (board) c; b.finish();
                }
                if (touchY > getHeight() * 0.33 && touchY < getHeight() * 0.66) {
                    Intent intent = new Intent(c, boll.class);
                    c.startActivity(intent);
                    return true;
                }
                if (touchY > getHeight() * 0.67 && touchY < getHeight()*0.82) {
                    MainActivity.Angel++;
                    MainActivity.CheckParam();

                }
                if (touchY > getHeight() * 0.84) {
                    MainActivity.Angel--;
                    MainActivity.CheckParam();

                }
            }
            //меняем положение шара
            if (touchY > getHeight() * 0.03 +main.shDiam*coeff/1000.0/2 && touchY < 0.97 * getHeight() - main.shDiam*coeff/1000.0/2 &&
                    touchX > getWidth() * 0.15 + main.shDiam*coeff/1000.0/2 && touchX < main.sizXm * coeff + getWidth() * 0.15 - main.shDiam*coeff/1000.0/2) {
                //обновляем положение шара в глобальных переменных
                main.x1=(touchX-getWidth()*0.15)/coeff;
                main.y1=(touchY-getHeight()*0.03)/coeff;
            }
        }
        invalidate();
        return true;
    }

    public void Calculate(){

        //обнуляем траекторию
        line1.removeAll(line1);
        line2.removeAll(line2);
        Pos p = new Pos();
        line1.add(p);
        p = new Pos();
        line2.add(p);

        //заполняем начальное положение шара из глобальных переменных
        coeff=getHeight()*0.94/main.sizYm;
        line1.get(0).X=main.x1*coeff+getWidth()*0.15;
        line1.get(0).Y=main.y1*coeff+getHeight()*0.03;
        line1.get(0).F=main.Angel;
        line1.get(0).V0 = main.Hit;
        line2.get(0).X=main.x2*coeff+getWidth()*0.15;
        line2.get(0).Y=main.y2*coeff+getHeight()*0.03;
        line2.get(0).F=0;
        line2.get(0).V0 =0;

        boolean fl=true;

        //рассчитываем новое положение, пока скорость не упадет до нуля
        while ((line1.get(line1.size() - 1).V0 > 0) || (line2.get(line2.size() - 1).V0 > 0)) {
            //Рассчитываем новой положение шара 1
            p = new Pos();
            p.X = line1.get(line1.size() - 1).X;
            p.Y = line1.get(line1.size() - 1).Y;
            p.F = line1.get(line1.size() - 1).F;
            p.V0 = line1.get(line1.size() - 1).V0;
            newPos(p);
            line1.add(p);
            //расчитываем новое положение шара 2
            p = new Pos();
            p.X = line2.get(line2.size() - 1).X;
            p.Y = line2.get(line2.size() - 1).Y;
            p.F = line2.get(line2.size() - 1).F;
            p.V0 = line2.get(line2.size() - 1).V0;
            newPos(p);
            line2.add(p);

            //проверяем столкновение между шарами
            double dx,dy,ds;
            dx=line1.get(line1.size() - 1).X-line2.get(line2.size() - 1).X;
            dy=line1.get(line1.size() - 1).Y-line2.get(line2.size() - 1).Y;
            ds=Math.sqrt(dx*dx+dy*dy);

            if (ds<main.shDiam*coeff/1000.0){
                if(fl) {
                    double dlinX1, dlinX2, dlinY1, dlinY2;
                    fl=false;

                    //длинны векторов
                    dlinX1 = Math.sin(line1.get(line1.size() - 1).F * Math.PI / 180.0);
                    dlinY1 = Math.cos(line1.get(line1.size() - 1).F * Math.PI / 180.0);
                    dlinX2 = line2.get(line2.size() - 1).X - line1.get(line1.size() - 1).X;
                    dlinY2 = 0-(line2.get(line2.size() - 1).Y - line1.get(line1.size() - 1).Y);

                    System.err.println("вектор1:("+dlinX1+","+dlinY1+"), вектор2:("+dlinX2+","+dlinY2+")");
                    //косинус угла альфа между векторами
                    double co = (dlinX1 * dlinX2 + dlinY1 * dlinY2) / (Math.sqrt(dlinX1 * dlinX1 + dlinY1 * dlinY1) * Math.sqrt(dlinX2 * dlinX2 + dlinY2 * dlinY2));
                    //Toast.makeText(c, Double.toString(co), Toast.LENGTH_SHORT).show();

                    //угол альфа
                    double a = Math.acos(co) / Math.PI * 180.0;

                    //считаем угол оси столконовения от оси начала отсчета углов

                    double b;
                    b= dlinY2 / Math.sqrt(dlinX2 * dlinX2 + dlinY2 * dlinY2);
                    b = Math.acos(b) / Math.PI * 180.0;
                    if(line2.get(line2.size() - 1).X - line1.get(line1.size() - 1).X <0) b=360-b;

                    //Toast.makeText(c, Double.toString(a), Toast.LENGTH_SHORT).show();
                    System.err.println("a="+a+", b="+b+"F="+(line1.get(line1.size() - 1).F));

                    //меняем направление движения
                    if(b-line1.get(line1.size() - 1).F<90 && b-line1.get(line1.size() - 1).F>0) {
                        line2.get(line2.size() - 1).F = (line1.get(line1.size() - 1).F + a)%360.0;
                        line1.get(line1.size() - 1).F = (line1.get(line1.size() - 1).F -(90-a))%360.0;

                    }
                    else{
                        line2.get(line2.size() - 1).F = (line1.get(line1.size() - 1).F - a)%360.0;
                        line1.get(line1.size() - 1).F = (line1.get(line1.size() - 1).F + (90-a))%360.0;
                    }

                    if(line2.get(line2.size() - 1).F<0)  line2.get(line2.size() - 1).F=360+line2.get(line2.size() - 1).F;
                    if(line1.get(line1.size() - 1).F<0)  line1.get(line1.size() - 1).F=360+line1.get(line1.size() - 1).F;

                    //меняем скорость движения
                    line2.get(line2.size() - 1).V0 = line1.get(line1.size() - 1).V0 * Math.cos(a * Math.PI / 180.0);
                    line1.get(line1.size() - 1).V0 = line1.get(line1.size() - 1).V0 * Math.sin(a * Math.PI / 180.0);
                }

            }
            else fl = true;
        }
    }
    public void newPos(Pos p)
    {

        double dS = p.V0 * main.Inter / 1000.0*coeff;
        p.X = p.X + dS * Math.sin(p.F * Math.PI / 180.0);
        p.Y = p.Y - dS * Math.cos(p.F * Math.PI / 180.0);
        p.V0 = p.V0 - main.Slow * main.Inter/1000.0;
        if (p.V0 < 0) p.V0 = 0;

        //удар о левый край
        if (p.X < getWidth() * 0.15 + main.shDiam*coeff/1000.0/2) {
            p.F = 360-p.F;
            p.X = getWidth() * 0.15 + main.shDiam*coeff/1000.0/2;
        }
        //удар о верхний край
        if (p.Y < getHeight() * 0.03 +main.shDiam*coeff/1000.0/2) {
            p.F = 180-p.F;
            p.Y = getHeight() * 0.03 +main.shDiam*coeff/1000.0/2;
        }
        //удар о правый край
        if (p.X > main.sizXm * coeff + getWidth() * 0.15 - main.shDiam*coeff/1000.0/2) {
            p.F = 360-p.F;
            p.X = main.sizXm * coeff + getWidth() * 0.15 - main.shDiam*coeff/1000.0/2;
        }
        //удар о нижний край
        if (p.Y > 0.97 * getHeight() - main.shDiam*coeff/1000.0/2) {
            p.F = 180-p.F;
            p.Y = 0.97 * getHeight() - main.shDiam*coeff/1000.0/2;
        }
    }
}
