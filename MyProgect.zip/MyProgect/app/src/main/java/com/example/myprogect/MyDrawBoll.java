package com.example.myprogect;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.CountDownTimer;

import android.view.MotionEvent;
import android.view.View;


public class MyDrawBoll extends View {
    static Paint paint = new Paint();;
    static Canvas canvas;
    int touchX=-50, touchY=-50;

    public MyDrawBoll(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvasD) {
        super.onDraw(canvasD);
        canvas = canvasD;
      //paint = new Paint();
        // Выбираем кисть
        paint.setStyle(Paint.Style.FILL);
        // Белый цвет кисти
        paint.setColor(Color.BLACK);
        // Закрашиваем холст
        canvas.drawPaint(paint);
        // Включаем антиальясинг
        paint.setAntiAlias(true);
        //Сам шар
        paint.setColor(Color.WHITE);
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, 200, paint);

        //кнопка
        //canvas.drawRect(10,10,10,10,paint);
        //рисуем кружок
        paint.setColor(Color.RED);
        canvas.drawCircle(touchX, touchY, 35, paint);

    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean flag = false;
        System.err.println("Start onTouch!!!!");
        int eventAction = event.getAction();
        if (eventAction == MotionEvent.ACTION_DOWN)  {

            touchX=(int) event.getX();
            touchY= (int) event.getY();

            if (getY()<getHeight()/20&&getX()<getHeight()/20){}

            invalidate ();


        }

        return true;
    }


}
/*
// Полупрозрачный синий круг радиусом 100 пикселей в центре экрана
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, 100, paint);

//  Выбор цвета
        paint.setColor(Color.argb(127,0,0,255));

// Текст
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(30);
        canvas.drawText("Samsung IT school", 50, 100, paint);

// текст под углом
        float rotate_center_x = 200; //центр поворота по оси X
        float rotate_center_y = 200; // центр поворота по оси Y
        float rotate_angle = 45; //угол поворота

// поворачиваем холст
        canvas.rotate(-rotate_angle, rotate_center_x, rotate_center_y);


        paint.setColor(Color.BLACK);
        paint.setTextSize(40);

        canvas.drawText("Samsung IT school",0,450,paint);

// возвращаем холст на прежний угол
        canvas.rotate(rotate_angle, rotate_center_x, rotate_center_y);
* */