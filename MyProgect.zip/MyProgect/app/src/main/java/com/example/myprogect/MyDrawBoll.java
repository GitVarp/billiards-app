package com.example.myprogect;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

import android.widget.Toast;


public class MyDrawBoll extends View {
    MainActivity main = MainActivity.m;
    static Paint paint = new Paint();;
    static Canvas canvas;
    Context c = null;

    public MyDrawBoll(Context context) {
        super(context);
        c = context;

    }

    @Override
    protected void onDraw(Canvas canvasD) {
        super.onDraw(canvasD);
        canvas = canvasD;
        // Выбираем кисть
        paint.setStyle(Paint.Style.FILL);
        // Белый цвет кисти
        paint.setColor(Color.BLACK);
        // Закрашиваем холст
        canvas.drawPaint(paint);
        // Включаем антиальясинг
        paint.setAntiAlias(true);
        //Сам шар
        paint.setColor(Color.WHITE);
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, (int) (getWidth() * 0.3), paint);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, (int) (getWidth() * 0.01), paint);
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, (int) (getWidth() * 0.15), paint);
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, (int) (getWidth() * 0.10), paint);
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, (int) (getWidth() * 0.20), paint);
        canvas.drawLine((float) (getWidth() * 0.2), (float) (getHeight() * 0.5), (float) (getWidth() *0.8), (float) (getHeight() * 0.5) ,paint);
        canvas.drawLine((float) (getWidth() * 0.5), (float) (getHeight() * 0.2), (float) (getWidth() *0.5), (float) (getHeight() * 0.8) ,paint);

        //окантовка кнопок
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.DKGRAY);

        canvas.drawRect(0, 0, (float) (getWidth() * 0.5), (float) (getHeight() * 0.1), paint);

        //кнопки
        paint.setColor(Color.rgb(175,175,175));
        canvas.drawRect((float) (getWidth() * 0.01), (float) (getHeight() * 0.01), (float) (getWidth() * 0.49), (float) (getHeight() * 0.09),paint);
        paint.setColor(Color.RED);

        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize((float) (getWidth()*0.04));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("Назад", (float) (getWidth()*0.25),  (float) (getHeight() * 0.05- ((paint.descent() + paint.ascent()) / 2)),  paint);
        //
        paint.setColor(Color.WHITE);

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTextSize((float) (getWidth()*0.03));
        canvas.drawText("Расстояние от центра шара, процентов: " + (int)main.shR, (float) (getWidth()*0.05),  (float) (getHeight() * 0.15- ((paint.descent() + paint.ascent()) / 2)),  paint);
        canvas.drawText("Угол отклонения от вертикали: " + (int)main.shAng, (float) (getWidth()*0.05),  (float) (getHeight() * 0.20- ((paint.descent() + paint.ascent()) / 2)),  paint);

        //Рисуем место удара по шару
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.FILL);
        float x = (float) (getWidth()*0.5+getWidth()*0.3*main.shR/100.0*Math.sin(main.shAng*Math.PI/180.0));
        float y = (float) (getHeight()*0.5-getWidth()*0.3*main.shR/100.0*Math.cos(main.shAng*Math.PI/180.0));
        canvas.drawCircle(x, y, (int) (getWidth() * 0.05), paint);
        canvas.drawLine(x,y,(int) (getWidth() * 0.5), (int) (getHeight() * 0.5),paint);


    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int eventAction = event.getAction();
        if (eventAction == MotionEvent.ACTION_DOWN)  {
            int x=(int) event.getX();
            int y=(int) event.getY();
            double x0=getWidth()/2;
            double y0=getHeight()/2;
            double l= Math.sqrt((x-x0)*(x-x0)+(y-y0)*(y-y0));

            if (l < getWidth()*0.3*0.8){
                MainActivity.shR=l/(getWidth()*0.3)*100;
                MainActivity.shAng=Math.acos((y0-y)/l)/Math.PI*180.0;
                if(x0>x) MainActivity.shAng=360-MainActivity.shAng;
               // Toast.makeText(c, "x="+x+" y="+y+" x0="+x0+" y0="+y0, Toast.LENGTH_SHORT).show();
            }

            //нажатие на кнопку назад
            if (y< getHeight() * 0.1){
                if (x <getWidth()* 0.49){
                    boll b = (boll) c; b.finish();
                }
            }
            invalidate ();
        }
        return true;
    }


}
